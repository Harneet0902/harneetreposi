package org.si.spring.restjpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestjpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
