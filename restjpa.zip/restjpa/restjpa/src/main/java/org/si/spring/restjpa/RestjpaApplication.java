package org.si.spring.restjpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = {"org.si.spring.restjpa.controllers", "org.si.spring.restjpa.services"})
@EnableJpaRepositories(basePackages = {"org.si.spring.restjpa.repository"})
@EntityScan(basePackages = {"org.si.spring.restjpa.entity"})
public class RestjpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestjpaApplication.class, args);
	}

}
