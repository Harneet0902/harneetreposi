package org.si.spring.restjpa.services;

import java.util.List;

import org.si.spring.restjpa.dto.CategoryDTO;

public interface CategoryService {
	
	public boolean addNewCategory(CategoryDTO category);
	public List<CategoryDTO> allCategories();
	public CategoryDTO findByCategoryId(int categoryId);
		

}
