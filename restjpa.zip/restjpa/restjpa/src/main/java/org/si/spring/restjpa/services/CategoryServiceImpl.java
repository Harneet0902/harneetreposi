package org.si.spring.restjpa.services;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.si.spring.restjpa.dto.CategoryDTO;
import org.si.spring.restjpa.entity.Category;
import org.si.spring.restjpa.repository.CategoryRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CategoryServiceImpl implements CategoryService{
	
	@Autowired
	CategoryRepository categoryRepository;
	
	@Override
	public boolean addNewCategory(CategoryDTO category)
	{
		try {
			Category entityCategory = new Category();
			BeanUtils.copyProperties(category, entityCategory);
			categoryRepository.save(entityCategory);
			return true;
		}catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public List<CategoryDTO> allCategories() {
		// TODO Auto-generated method stub
		
		List<Category> listEntity = categoryRepository.findAll();
		List<CategoryDTO> listDTO = new ArrayList<>();
		 for(Category entity  :  listEntity)
		 {
			 CategoryDTO dto = new CategoryDTO();
			 BeanUtils.copyProperties(entity, dto);
			 listDTO.add(dto);
		 }
		 return	listDTO;
	}

	@Override
	public CategoryDTO findByCategoryId(int categoryId) {
		// TODO Auto-generated method stub
      Optional<Category> optCategory = categoryRepository.findById(categoryId);
      Category entity = optCategory.get();
      CategoryDTO dto = new CategoryDTO();
      BeanUtils.copyProperties(entity, dto);
      return dto;
	}

	
}
